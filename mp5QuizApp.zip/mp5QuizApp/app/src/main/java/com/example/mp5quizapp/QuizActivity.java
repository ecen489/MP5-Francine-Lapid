package com.example.mp5quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class QuizActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        TextView quizNameView = (TextView) findViewById(R.id.quizTypeView);
        TextView questionView = (TextView) findViewById(R.id.questionView);

        Intent intent = getIntent();
        final String quizTopic = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        quizNameView.setText(quizTopic + " Quiz");

        // Generate two random numbers
        final int operand1 = new Random().nextInt((10 - 1) + 1) + 1;
        final int operand2 = new Random().nextInt((10-1)+1)+1;

        // Put question in TextView
        String question = Integer.toString(operand1);
        if (quizTopic.equals("Addition")) {
            question += " + ";
        }
        else if (quizTopic.equals("Subtraction")) {
            question += " - ";
        }
        else {
            question += " x ";
        }
        question += Integer.toString(operand2) + " = ";
        questionView.setText(question);

        // Set up SEND ANSWER button
        Button sendAnswerButton = (Button) findViewById(R.id.buttonCheck);
        final EditText userAnswer = (EditText) findViewById(R.id.editText);
        final TextView accuracyView = (TextView) findViewById(R.id.accuracyView);
        sendAnswerButton.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v) {
                userAnswer.setEnabled(false);
                if(isCorrect(operand1, operand2, userAnswer.getText().toString(), quizTopic)) {
                    accuracyView.setText("Correct");
                    MainActivity.score++;
                }
                else {
                    accuracyView.setText("Wrong");
                }
                Button returnToMenuButton = (Button) findViewById(R.id.return_button);
                returnToMenuButton.setVisibility(View.VISIBLE);
                returnToMenuButton.setOnClickListener (new View.OnClickListener() {
                    public void onClick (View v) {
                        goBackToMenu();
                    }
                });
            }
        });
    }
    public void goBackToMenu() {
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);
    }
    public boolean isCorrect(int operand1, int operand2, String answer, String operation) {
        int user_answer_int = Integer.valueOf(answer);
        int correct_answer;

        // find correct answer
        if (operation.equals("Addition")) {
            correct_answer = operand1 + operand2;
        }
        else if (operation.equals("Subtraction")) {
            correct_answer = operand1 - operand2;
        }
        else {
            correct_answer = operand1 * operand2;
        }

        // return true if correct answer equals user's answer
        if (correct_answer == user_answer_int) {
            return true;
        }
        else {
            return false;
        }
    }
}