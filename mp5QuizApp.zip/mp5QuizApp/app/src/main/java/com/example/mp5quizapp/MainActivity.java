package com.example.mp5quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static int score = 0;
    String[] quizTopics = {"Addition", "Subtraction", "Multiplication"};
    String topicChosen;
    public static final String EXTRA_MESSAGE = "com.example.mp5quizapp.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter adapter = new ArrayAdapter<String> (this, R.layout.main_activity_listview, quizTopics);

        final ListView listview = (ListView) findViewById(R.id.listView);
        listview.setAdapter(adapter);
        final TextView scoreText = (TextView) findViewById(R.id.textScore);
        scoreText.setText("Score: " + Integer.toString(score));

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){
                topicChosen = (String) listview.getItemAtPosition(i);
                sendTopic(topicChosen);
            }
        });

        Button resetButton = (Button) findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v) {
                score = 0;
                scoreText.setText("Score: " + Integer.toString(score));
            }
        });
    }

    public void sendTopic(String s) {
        Intent intent = new Intent (this, QuizActivity.class);
        intent.putExtra(EXTRA_MESSAGE, topicChosen);
        startActivity(intent);
    }
}